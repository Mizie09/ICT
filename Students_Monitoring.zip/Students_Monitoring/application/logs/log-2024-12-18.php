<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$benchmark is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$hooks is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$config is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$log is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$utf8 is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$uri is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$exceptions is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$router is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$output is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$security is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$input is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$lang is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property Dashboard::$db is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-12-18 23:12:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-12-18 23:12:25 --> Severity: error --> Exception: Class "mysqli_driver" not found /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 123
ERROR - 2024-12-18 23:12:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Exceptions.php:272) /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Common.php 571
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$benchmark is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$hooks is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$config is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$log is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$utf8 is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$uri is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$exceptions is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$router is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$output is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$security is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$input is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$lang is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property Dashboard::$db is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-12-18 23:12:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/self/primary/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-12-18 23:12:55 --> Severity: error --> Exception: Class "mysqli_driver" not found /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 123
ERROR - 2024-12-18 23:12:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Exceptions.php:272) /storage/self/primary/MyWebsite/Students_Monitoring/system/core/Common.php 571
