<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-29 13:06:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-29 13:06:35 --> Unable to connect to the database
ERROR - 2024-11-29 13:17:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'Student_Monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-29 13:17:20 --> Unable to connect to the database
ERROR - 2024-11-29 13:17:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'Student_Monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-29 13:17:22 --> Unable to connect to the database
ERROR - 2024-11-29 13:33:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'Student_Monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-29 13:33:19 --> Unable to connect to the database
ERROR - 2024-11-29 13:36:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'Student_Monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-29 13:36:13 --> Unable to connect to the database
ERROR - 2024-11-29 13:38:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'Student_Monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-29 13:38:34 --> Unable to connect to the database
ERROR - 2024-11-29 16:20:37 --> Query error: Unknown column 'users_id' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `users_id` = 'abc-0000-0001'
AND `password` = 'c29edef4186860c91b1559507c47797c90ac6dd5ef7f79734ad7fdfeb49fb3a4'
AND `is_deleted` = 0
