<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-23 11:39:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 11:39:45 --> Unable to connect to the database
ERROR - 2024-11-23 12:11:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:11:23 --> Unable to connect to the database
ERROR - 2024-11-23 12:11:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:11:27 --> Unable to connect to the database
ERROR - 2024-11-23 12:12:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:12:25 --> Unable to connect to the database
ERROR - 2024-11-23 12:12:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:12:36 --> Unable to connect to the database
ERROR - 2024-11-23 12:16:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:16:46 --> Unable to connect to the database
ERROR - 2024-11-23 12:35:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:35:37 --> Unable to connect to the database
ERROR - 2024-11-23 12:39:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'student_monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:39:47 --> Unable to connect to the database
ERROR - 2024-11-23 12:40:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'student_monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:40:31 --> Unable to connect to the database
ERROR - 2024-11-23 12:40:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'student_monitoring_db' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-11-23 12:40:34 --> Unable to connect to the database
ERROR - 2024-11-23 14:15:59 --> Severity: error --> Exception: syntax error, unexpected '<' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/index.php 11
ERROR - 2024-11-23 14:45:22 --> Severity: Notice --> Undefined variable: user /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:45:26 --> Severity: Notice --> Undefined variable: user /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:46:44 --> Severity: Notice --> Undefined variable: user /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:46:44 --> Severity: Notice --> Trying to get property 'users_id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:46:49 --> Severity: Notice --> Undefined variable: user /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:46:49 --> Severity: Notice --> Trying to get property 'users_id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:47:13 --> Severity: Notice --> Undefined variable: session /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:47:28 --> Severity: Notice --> Undefined variable: user /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:47:31 --> Severity: Notice --> Undefined variable: user /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:47:43 --> Severity: Warning --> Use of undefined constant usr_info - assumed 'usr_info' (this will throw an Error in a future version of PHP) /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 23
ERROR - 2024-11-23 14:52:41 --> Severity: Notice --> Undefined variable: result /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 22
ERROR - 2024-11-23 14:53:09 --> Severity: Notice --> Undefined variable: result /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 13
ERROR - 2024-11-23 14:53:09 --> Severity: Notice --> Undefined variable: result /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 22
ERROR - 2024-11-23 14:53:14 --> Severity: Notice --> Undefined variable: result /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 13
ERROR - 2024-11-23 14:53:14 --> Severity: Notice --> Undefined variable: result /storage/self/primary/MyWebsite/Students_Monitoring/application/views/templates/header.php 22
ERROR - 2024-11-23 14:54:54 --> Severity: Warning --> Use of undefined constant usr_info - assumed 'usr_info' (this will throw an Error in a future version of PHP) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Login.php 35
ERROR - 2024-11-23 15:32:16 --> Severity: error --> Exception: Too few arguments to function Employees::delete(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 110
ERROR - 2024-11-23 15:41:52 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 129
ERROR - 2024-11-23 15:41:57 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 129
ERROR - 2024-11-23 15:42:09 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 129
ERROR - 2024-11-23 15:42:13 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 129
ERROR - 2024-11-23 15:42:23 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 129
ERROR - 2024-11-23 15:43:53 --> Severity: error --> Exception: Too few arguments to function Employees::delete(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 110
ERROR - 2024-11-23 15:46:00 --> Severity: error --> Exception: Too few arguments to function Employees::delete(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 110
ERROR - 2024-11-23 15:46:04 --> Severity: error --> Exception: Too few arguments to function Employees::delete(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 110
ERROR - 2024-11-23 18:05:30 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 134
ERROR - 2024-11-23 18:31:48 --> 404 Page Not Found: Employees/edit
ERROR - 2024-11-23 19:25:26 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 93
ERROR - 2024-11-23 19:26:35 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 93
ERROR - 2024-11-23 19:31:44 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 102
ERROR - 2024-11-23 19:37:57 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 19:39:25 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 19:39:26 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/nav.php 21
ERROR - 2024-11-23 19:40:13 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/nav.php 21
ERROR - 2024-11-23 19:42:02 --> Severity: error --> Exception: syntax error, unexpected '<' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/nav.php 21
ERROR - 2024-11-23 19:42:22 --> Severity: error --> Exception: syntax error, unexpected '<' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/nav.php 21
ERROR - 2024-11-23 19:42:31 --> Severity: error --> Exception: syntax error, unexpected '?' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/nav.php 21
ERROR - 2024-11-23 19:42:41 --> Severity: error --> Exception: syntax error, unexpected '?' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/dashboard/nav.php 21
ERROR - 2024-11-23 19:44:15 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 19:45:45 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 19:45:47 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 6
ERROR - 2024-11-23 19:46:02 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 19:47:24 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 19:50:56 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 19:52:02 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 19:52:29 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:38:57 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:40:17 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:44:48 --> Severity: error --> Exception: syntax error, unexpected '!', expecting variable (T_VARIABLE) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:45:08 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:45:33 --> Severity: Warning --> Use of undefined constant id - assumed 'id' (this will throw an Error in a future version of PHP) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 71
ERROR - 2024-11-23 20:45:33 --> Severity: Notice --> Trying to get property 'id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 6
ERROR - 2024-11-23 20:46:13 --> Severity: Notice --> Trying to get property 'id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 6
ERROR - 2024-11-23 20:46:18 --> Severity: Notice --> Trying to get property 'id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 6
ERROR - 2024-11-23 20:46:39 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:50:04 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 20:52:10 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 69
ERROR - 2024-11-23 21:01:22 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:03:56 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:04:09 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:06:14 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 108
ERROR - 2024-11-23 21:06:34 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 108
ERROR - 2024-11-23 21:06:36 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 108
ERROR - 2024-11-23 21:06:54 --> Severity: error --> Exception: syntax error, unexpected '-', expecting variable (T_VARIABLE) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 108
ERROR - 2024-11-23 21:07:02 --> Severity: error --> Exception: syntax error, unexpected 'vardump' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 108
ERROR - 2024-11-23 21:08:19 --> Severity: Notice --> Undefined variable: data /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 109
ERROR - 2024-11-23 21:08:37 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 109
ERROR - 2024-11-23 21:08:39 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 109
ERROR - 2024-11-23 21:08:48 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 110
ERROR - 2024-11-23 21:09:02 --> Severity: Notice --> Undefined variable: new_password /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 110
ERROR - 2024-11-23 21:09:15 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 108
ERROR - 2024-11-23 21:10:04 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:10:07 --> Severity: Notice --> Undefined variable: new_password /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 36
ERROR - 2024-11-23 21:10:15 --> Severity: Notice --> Undefined variable: new_password /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 36
ERROR - 2024-11-23 21:12:07 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:12:42 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:12:47 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:14:26 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:15:19 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:15:20 --> Severity: Notice --> Undefined variable: id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 6
ERROR - 2024-11-23 21:20:55 --> 404 Page Not Found: Profile/change_pword
ERROR - 2024-11-23 21:20:57 --> 404 Page Not Found: Profile/change_pword
ERROR - 2024-11-23 21:20:59 --> 404 Page Not Found: Profile/change_pword
ERROR - 2024-11-23 21:22:07 --> 404 Page Not Found: Profile/change_pword
ERROR - 2024-11-23 21:22:10 --> 404 Page Not Found: Profile/change_pword
ERROR - 2024-11-23 21:24:36 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:28:50 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:29:16 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:29:21 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:29:43 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:29:54 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:30:33 --> 404 Page Not Found: Employees/change_password
ERROR - 2024-11-23 21:30:36 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 21:30:40 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 21:30:48 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 21:31:02 --> 404 Page Not Found: Profile/change_password
ERROR - 2024-11-23 21:32:01 --> 404 Page Not Found: Profile/change_pword1
ERROR - 2024-11-23 21:32:48 --> 404 Page Not Found: Profile/change_pword1
ERROR - 2024-11-23 21:37:34 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:37:48 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:38:11 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:38:52 --> Severity: Notice --> Trying to get property 'id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/change_pword.php 18
ERROR - 2024-11-23 21:40:15 --> Severity: error --> Exception: Too few arguments to function Profile::change_pword(), 0 passed in /storage/self/primary/MyWebsite/Students_Monitoring/system/core/CodeIgniter.php on line 533 and exactly 1 expected /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 70
ERROR - 2024-11-23 21:50:05 --> Severity: Warning --> Use of undefined constant password - assumed 'password' (this will throw an Error in a future version of PHP) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 94
ERROR - 2024-11-23 21:50:05 --> Severity: Notice --> Undefined variable: new /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 94
ERROR - 2024-11-23 21:50:05 --> Severity: Warning --> A non-numeric value encountered /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 94
ERROR - 2024-11-23 22:15:03 --> Severity: Warning --> Use of undefined constant password - assumed 'password' (this will throw an Error in a future version of PHP) /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 40
ERROR - 2024-11-23 22:15:03 --> Severity: Notice --> Undefined variable: new /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 40
ERROR - 2024-11-23 22:15:03 --> Severity: Warning --> A non-numeric value encountered /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 40
ERROR - 2024-11-23 22:17:15 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 36
ERROR - 2024-11-23 22:18:48 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 36
ERROR - 2024-11-23 22:18:49 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 36
ERROR - 2024-11-23 22:18:50 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 36
ERROR - 2024-11-23 22:18:55 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 36
ERROR - 2024-11-23 22:18:56 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 36
ERROR - 2024-11-23 22:19:40 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 37
ERROR - 2024-11-23 22:20:33 --> Severity: error --> Exception: syntax error, unexpected '=' /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Profile.php 37
ERROR - 2024-11-23 23:03:21 --> Severity: error --> Exception: syntax error, unexpected ',' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/employees/index.php 41
ERROR - 2024-11-23 23:03:45 --> Severity: Warning --> A non-numeric value encountered /storage/self/primary/MyWebsite/Students_Monitoring/application/views/employees/index.php 41
ERROR - 2024-11-23 23:05:38 --> Severity: error --> Exception: syntax error, unexpected '.' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/employees/index.php 41
