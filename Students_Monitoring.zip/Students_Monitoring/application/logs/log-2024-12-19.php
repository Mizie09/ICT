<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-19 07:30:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /storage/self/primary/MyWebsite/Students_Monitoring/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-12-19 07:30:49 --> Unable to connect to the database
