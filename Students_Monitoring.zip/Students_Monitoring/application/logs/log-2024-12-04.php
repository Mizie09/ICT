<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-04 13:29:38 --> Severity: Notice --> Trying to get property 'users_id' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/controllers/Employees.php 48
