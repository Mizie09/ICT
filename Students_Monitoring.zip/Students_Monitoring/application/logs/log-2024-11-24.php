<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-24 11:32:50 --> Severity: Notice --> Undefined property: stdClass::$user_id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 3
ERROR - 2024-11-24 11:32:50 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 8
ERROR - 2024-11-24 13:15:32 --> Severity: Notice --> Undefined property: stdClass::$user_id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 3
ERROR - 2024-11-24 13:15:32 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 8
ERROR - 2024-11-24 13:17:24 --> Severity: Notice --> Undefined property: stdClass::$user_id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 9
ERROR - 2024-11-24 13:17:24 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:17:25 --> Severity: Notice --> Undefined property: stdClass::$user_id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 9
ERROR - 2024-11-24 13:17:25 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:17:28 --> Severity: Notice --> Undefined property: stdClass::$user_id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 9
ERROR - 2024-11-24 13:17:28 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:17:50 --> Severity: Notice --> Undefined property: stdClass::$user_id /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 9
ERROR - 2024-11-24 13:17:50 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:19:17 --> Severity: Notice --> Trying to get property 'profile_picture' of non-object /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:20:07 --> Severity: Notice --> Undefined property: stdClass::$profile_picture /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:21:56 --> Severity: Notice --> Undefined property: stdClass::$profile_picture /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:22:04 --> Severity: Notice --> Undefined property: stdClass::$profile_picture /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:22:21 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 16
ERROR - 2024-11-24 13:23:57 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting ')' /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 12
ERROR - 2024-11-24 13:25:28 --> Severity: Notice --> Undefined property: stdClass::$profile_picture /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 11
ERROR - 2024-11-24 13:30:28 --> Severity: Notice --> Undefined property: stdClass::$profile_picture /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 11
ERROR - 2024-11-24 13:30:31 --> Severity: Notice --> Undefined property: stdClass::$profile_picture /storage/self/primary/MyWebsite/Students_Monitoring/application/views/profile/index.php 11
ERROR - 2024-11-24 13:30:46 --> 404 Page Not Found: Profile/profile_picture
ERROR - 2024-11-24 13:30:51 --> 404 Page Not Found: Profile/profile_picture
