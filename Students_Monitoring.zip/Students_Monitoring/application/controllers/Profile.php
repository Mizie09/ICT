<?php

class Profile extends CI_Controller
{
  public function __construct()
    {
        parent::__construct();
        
        if(!$this->session->userdata('usr_info'))
            redirect('Login');
        
       
        $this->load->model('Users_model');
    }
    public function index()
    {
        $data['users'] = $this->Users_model->rows();
        $this->load->view('templates/header');
        $this->load->view('employees/nav');
        $this->load->view('profile/index', $data);
        $this->load->view('templates/footer');
        
    }
    
    public function change_pword($id) 
    {
        $this->form_validation->set_rules('current_password', 'Current Password', 'trim|required');
        $this->form_validation->set_rules('new_password', 'New Password', 'trim|required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[new_password]');

        if ($this->form_validation->run())
        {
         $user = $this->Users_model->row($id);
        if ($user && hash('sha256', $this->input->post('current_password')) === $user->password)
        {
            
            $new_password = hash('sha256', $this->input->post('new_password'));

            
            $data = array(
                'password' => $new_password,
                'edited_by' => $this->session->userdata('usr_info')->users_id,
                'edited_at' => date('Y-m-d')
            );
            $result = $this->Users_model->update($id, $data);

            if ($result) {
                $this->session->set_flashdata('msg', 'Password updated successfully.');
                redirect('Profile/change_pword/'. $id);
            } else {
                $this->session->set_flashdata('errmsg', 'Password update failed.');
                redirect('Profile/change_pword/' . $id);
            }
        } else {
            
            $this->session->set_flashdata('errmsg', 'Incorrect current password.');
            redirect('Profile/change_pword/' . $id);
        }
       
        
    } 
        $data['user'] = $this->Users_model->row($id); // Get user data
        $this->load->view('templates/header');
        $this->load->view('dashboard/nav');
        $this->load->view('profile/change_pword', $data);
        $this->load->view('templates/footer');
    
    }
    //AI tutorial
   

    public function upload() {
        $config['upload_path'] = './uploads/profile_pictures/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 2048; // 2MB max size
        $config['file_name'] = time(); // Unique file name

        $this->upload->initialize($config);

        if ($this->upload->do_upload('profile_picture')) {
            // File upload successful
            $upload_data = $this->upload->data();
            $profile_picture = 'uploads/profile_pictures/' . $upload_data['file_name'];

            // Update the profile picture in the database
            $user_id = $this->session->userdata('user_id'); // Assuming user ID is stored in the session
            $this->Users_model->update_profile_picture($user_id, $profile_picture);

            // Redirect or show success message
            redirect('profile');
        } else {
            // Handle upload error
            $error = $this->upload->display_errors();
            echo $error;
        }
    }


    
}
