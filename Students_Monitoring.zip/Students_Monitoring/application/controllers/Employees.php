<?php

class Employees extends CI_Controller
{
  public function __construct()
    {
        parent::__construct();
        
        if(!$this->session->userdata('usr_info'))
            redirect('Login');
        
       
        $this->load->model('Users_model');
    }
    public function index()
    {
        $data['users'] = $this->Users_model->rows();
        $this->load->view('templates/header');
        $this->load->view('employees/nav');
        $this->load->view('employees/index', $data);
        $this->load->view('templates/footer');
        
    }
    public function add()
    {
        $this->form_validation->set_rules('users_id','Employees No.','trim|required');
        $this->form_validation->set_rules('department','Department.','trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('middle_name', 'Middle Name', 'trim|required');
        $this->form_validation->set_rules('birthday', 'Birthday', 'trim|required');
        $this->form_validation->set_rules('age', 'Age', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        
        if ($this->form_validation->run())
            
        {
            $data = array(
            'users_id'   => $this->input->post('users_id'),
            'password'   => hash('sha256', 'default'),
            'last_name'  => $this->input->post('last_name'),
            'first_name' => $this->input->post('first_name'),
            'middle_name'=> $this->input->post('middle_name'),
            'birthday'   => $this->input->post('birthday'),
            'age'        => $this->input->post('age'),
            'email'      => $this->input->post('email'),
            'department' => $this->input->post('department'),
            'created_by' => $this->session->userdata('usr_info')->users_id,
            'created_at' => date ('Y-m-d')
            );
         $result = $this->Users_model->add($data);
        
         if ($result) {
            $this->session->set_flashdata('msg', 'Succesfully');
            redirect('Employees');
         }
         else {
             $this->session->set_flashdata('errmsg', 'Failed');
            redirect('Employees/add');
         }
        }
         $this->load->view('templates/header');
        $this->load->view('employees/nav');
        $this->load->view('employees/add');
        $this->load->view('templates/footer');
    }
    public function update($id) 
    {
        $this->form_validation->set_rules('users_id','Employees No.','trim|required');
        $this->form_validation->set_rules('department','Department.','trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('middle_name', 'Middle Name', 'trim|required');
        $this->form_validation->set_rules('birthday', 'Birthday', 'trim|required');
        $this->form_validation->set_rules('age', 'Age', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        
        if ($this->form_validation->run())
            
        {
            $data = array(
            'users_id'   => $this->input->post('users_id'),
            'last_name'  => $this->input->post('last_name'),
            'first_name' => $this->input->post('first_name'),
            'middle_name'=> $this->input->post('middle_name'),
            'birthday'   => $this->input->post('birthday'),
            'age'        => $this->input->post('age'),
            'email'      => $this->input->post('email'),
            'department' => $this->input->post('department'),
            'edited_by'  => $this->session->userdata('usr_info')->users_id,
            'edited_at'  => date ('Y-m-d')
            );
         $result = $this->Users_model->update($id, $data);
        if ($result) {
            $this->session->set_flashdata('msg', 'Succesfully');
            redirect('Employees');
         }
         else {
             $this->session->set_flashdata('errmsg', 'Failed');
            redirect('Employees/update');
         }
    }
        $data['user'] = $this->Users_model->row($id);
        
        $this->load->view('templates/header');
        $this->load->view('employees/nav');
        $this->load->view('employees/edit', $data);
        $this->load->view('templates/footer');
    }
    public function delete($id) 
    {
        
        if ($this->input->post('confirm'))
            
        {
            $data = array(
            'is_deleted' => 1,
            'deleted_by'  => $this->session->userdata('usr_info')->users_id,
            'deleted_at'  => date ('Y-m-d')
            );
         $result = $this->Users_model->delete($id, $data);
            
            
        if ($result) {
            $this->session->set_flashdata('msg', 'User Deleted Succesfully!');
           
         }
         else {
             $this->session->set_flashdata('errmsg', 'Failed to Delete a User!');

         }
         redirect('Employees');

         } 
        elseif ($this->input->post('cancel')){
             $this->session->set_flashdata('msg', 'Deletetion Cancelled!');
            redirect('Employees');
             
         }
                $data['user'] = $this->Users_model->row($id);
        
        $this->load->view('templates/header');
        $this->load->view('employees/nav');
        $this->load->view('employees/delete', $data);
        $this->load->view('templates/footer');
    
    }

    
        
    
}