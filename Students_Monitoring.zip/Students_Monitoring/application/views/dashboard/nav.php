		
								<div>
<div class="bg-primary" ><h3>Student Monitoring</h3></div>			
							
<?php 
if($this->session->userdata('usr_info')){
    $user = $this->session->userdata('usr_info');
    
    ?>
    
    <div class="dropdown text-right">
    					
  <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
   <?= $user->users_id; ?>
  </button>
  <div class="dropdown-menu">
    <button class="dropdown-item" type="button">
    <a href="<?= site_url('Profile')?>">Profile</a>
    </button>
     <button class="dropdown-item" type="button">
    <a href="<?= site_url('profile/change_pword/'.$user->id)?>">Change Password</a>
    </button>
    <button class="dropdown-item" type="button">
    <a href="<?= site_url('login/logout')?>">Log out</a>
    </button>
    
  </div>
</div>
<?php } ?>
								</div>
								<div>
					<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="<?= site_url('Dashboard') ?>">Dashboard<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= site_url('Employees')?>">Employees</a>
      </li>

    </ul>
  </div>
</nav>
												</div>