</div>
    <script src="<?= base_url('assets/js/jquery.js')?>"></script>
<script src="<?= base_url('assets/js/popper.js')?>"></script>
<script src="<?= base_url('assets/js/bootstrap.js')?>"></script>
<script src="<?= base_url('assets/datatables/datatables.js')?>"></script>
<script>
new DataTable('#myTable', {
    order: [[3, 'desc']]
});
</script>
</body>
</html>