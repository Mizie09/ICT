<form action="<?= site_url('Login/login') ?>" method="post">
  <div class="container">
  						<div class="row">
        <div class="col-md-10 offset-md-1">
            <div class="card mt-5">
                <div class="card-header text-center">
                    <span class="display-4 font-weight-bold text-primary">Login to continue</span>
                </div>
                <div class="card-body">
                     <div class="card-title">
                         <label for="users_id">Employee No.</label>
                         <input name="users_id" type="text" class="form-control" id="" placeholder="abc-0000-0000">
                     </div>
                     <div class="card-title">
                         <label for="password">Password</label>
                         <input name="password" type="password" class="form-control" id="" placeholder="password">
                           <?php echo form_error('password'); ?>
                     </div>
                     <div class="card-title">
                         <input type="submit" class="btn btn-primary" id="" value="LOGIN">
                     </div>
                </div>
            </div>
        </div>
  
    </div>
  </div>
  </form>