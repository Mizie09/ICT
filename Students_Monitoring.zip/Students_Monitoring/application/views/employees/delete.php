<?php if ($this->session->flashdata('msg')): ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('msg'); ?>
    </div>
<?php endif; ?>

<?php if ($this->session->flashdata('errmsg')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('errmsg'); ?>
    </div>
<?php endif; ?>
<div class="container">
    <h3>Confirm Deletion</h3>
    <p>Are you sure you want to delete the user: <strong><?= $user->users_id ?></strong>?</p>

    <!-- Confirmation Form -->
    <form method="post" action="<?= site_url('Employees/delete/'.$user->id) ?>">
        <input type="submit" name="confirm" class="btn btn-danger" value="Delete">
        <input type="submit" name="cancel" class="btn btn-secondary" value="Cancel">
    </form>
</div>
