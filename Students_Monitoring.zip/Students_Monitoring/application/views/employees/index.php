
    <div>
        <div>
            <h3>Employees</h3>
        </div>
        <div>
            
            <a class="btn btn-primary" href="<?= site_url('Employees/add') ?>">Add</a>
        </div>
        <div>
<?php if ($this->session->flashdata('msg')): ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('msg'); ?>
    </div>
<?php endif; ?>

<?php if ($this->session->flashdata('errmsg')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('errmsg'); ?>
    </div>
<?php endif; ?>

            <table id="myTable" class="">
<thead>
                <tr>
                    <th>Employee No.</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach ($users as $user):
                        ?>
                <tr>
                   <td><?= $user->users_id; ?></td>
                   <td><?= $user->last_name .", ".$user->first_name." ". $user->middle_name; ?></td>

                   <td><?= $user->age; ?></td>
                   <td><?= $user->email ?></td>
                   <td><?= $user->department; ?></td>
                   <td><a class="btn btn-success" href="<?= site_url('Employees/update/'.$user->id ) ?>">Edit</a> | <a class="btn btn-danger" href="<?= site_url('Employees/delete/'.$user->id ) ?>">Delete</a></td>
                </tr>
                        <?php endforeach ?>
</tbody>
            </table>
        </div>
    </div>