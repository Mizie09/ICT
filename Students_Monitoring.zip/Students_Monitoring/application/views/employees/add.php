<div>
        <h3>Employees</h3>
        </div>
        <div>
            <form action="<?= site_url('Employees/add')?>" method="post">
                    
                    <?php
                    if (validation_errors())
                    {
                            echo validation_errors();
                    }
                    ?>
                            <div class="form-group">
                            <label for="users_id">Employee No. <span class="text-danger">*</span></label>
                                    <input name="users_id" type="text" class="form-control" id="" placeholder="abc-0000-0000">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="last_name">Last Name:</label>
                                    <input name="last_name" type="text" class="form-control" id="" placeholder="Last Name">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="first_name">First Name:</label>
                                    <input name="first_name"  type="text" class="form-control" id="" placeholder="First Name">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="middle_name">Middle Name:</label>
                                    <input name="middle_name"  type="text" class="form-control" id="" placeholder="Middle Name">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="birthday">Birthday:</label>
                                    <input name="birthday" type="date" class="form-control" id="" placeholder="">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="age">Age:</label>
                                    <input name="age"  type="number" class="form-control" id="" placeholder="">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="email">Email:</label>
                                    <input name="email" type="email" class="form-control" id="" placeholder="your@email.com">
                                    </div>
                                    
                                      <div class="form-group">
    <label for="department">Department. <span class="text-danger">*</span></label>
    <select name="department" class="form-control" id="department">
      <option value="">choose</option>
      <option value="IT">IT</option>
      <option value="Finance">Finance</option>
      <option value="Registar">Registar</option>
      
    </select>
  </div>
            
            <input class="btn btn-success" type="submit" value="Submit" >


            </form>
        </div>