
        <div>
            <h3>Employees</h3>
        </div>
        <div>
            <form action="<?= site_url('Employees/update/'.$user->id)?>" method="post">
                    
                    <?php
                    if (validation_errors())
                    {
                            echo validation_errors();
                    }
                    ?>

                            <div class="form-group">
                            <label for="users_id">Employee No. <span class="text-danger">*</span></label>
                                    <input name="users_id" type="text" class="form-control" id="" value="<?= $user->users_id ?>">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="last_name">Last Name:</label>
                                    <input name="last_name" type="text" class="form-control" id="" value="<?= $user->last_name ?>">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="first_name">First Name:</label>
                                    <input name="first_name"  type="text" class="form-control" id="" value="<?= $user->first_name ?>">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="middle_name">Middle Name:</label>
                                    <input name="middle_name"  type="text" class="form-control" id="" value="<?= $user->middle_name ?>">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="birthday">Birthday:</label>
                                    <input name="birthday" type="date" class="form-control" id="" value="<?= $user->birthday ?>">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="age">Age:</label>
                                    <input name="age"  type="number" class="form-control" id="" value="<?= $user->age ?>">
                                    </div>
                                    
                                    <div class="form-group">
                            <label for="email">Email:</label>
                                    <input name="email" type="email" class="form-control" id="" value="<?= $user->email ?>">
                                    </div>
                                    
                                      <div class="form-group">
    <label for="department">Department. <span class="text-danger">*</span></label>
    <select name="department" class="form-control" id="department">
      <option value="<?= $user->department ?>"><?= $user->department ?></option>
      <option value="IT">IT</option>
      <option value="Finance">Finance</option>
      <option value="Registar">Registar</option>
      
    </select>
  </div>
            
            <input class="btn btn-success" type="submit" value="Update" >

            </form>
        </div>