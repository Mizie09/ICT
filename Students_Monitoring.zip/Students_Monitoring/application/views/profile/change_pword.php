<div class="container">
    <h3>Change Password</h3>
    
    <!-- Display Flash Message -->
    <?php if ($this->session->flashdata('msg')): ?>
        <div class="alert alert-success">
            <?php echo $this->session->flashdata('msg'); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($this->session->flashdata('errmsg')): ?>
        <div class="alert alert-danger">
            <?php echo $this->session->flashdata('errmsg'); ?>
        </div>
    <?php endif; ?>

    <!-- Change Password Form -->
<form action="<?= site_url('Profile/change_pword/' . $user->id); ?>" method="post">
        <div class="form-group">
            <label for="current_password">Current Password</label>
            <input type="password" class="form-control" id="current_password" name="current_password" >
            <?php echo form_error('current_password'); ?>
        </div>
        
        <div class="form-group">
            <label for="new_password">New Password</label>
            <input type="password" class="form-control" id="new_password" name="new_password" >
            <?php echo form_error('new_password'); ?>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Confirm New Password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" >
            <?php echo form_error('confirm_password'); ?>
        </div>
        
        <button type="submit" class="btn btn-primary">Change Password</button>
</form>
</div>
