<div>
 <span>

<strong>username: <?= $this->session->userdata('usr_info')->users_id; ?></strong>

</span>
</div>